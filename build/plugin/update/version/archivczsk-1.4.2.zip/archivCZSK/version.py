from . import _

title = _("ArchivCZSK")
version = "1.4.2"
author = "mx3L,misanov"
description = _("Playing CZ/SK archives")
url = "https://github.com/mx3L/archivczsk/"
email = "archivczsk@seznam.cz"
